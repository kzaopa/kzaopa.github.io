## Empire Version


## OS Information (Linux flavor, Python version)


## Expected behavior and description of the error, including any actions taken immediately prior to the error. The more detail the better.


## Screenshot of error, embedded text output, or Pastebin link to the error


## Any additional information
